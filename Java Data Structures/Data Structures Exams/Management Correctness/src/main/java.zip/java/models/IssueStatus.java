package models;

public enum IssueStatus {
    TO_DO,
    IN_PROGRESS,
    DONE
}
