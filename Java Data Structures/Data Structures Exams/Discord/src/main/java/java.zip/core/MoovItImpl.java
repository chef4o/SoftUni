package core;

import models.Route;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class MoovItImpl implements MoovIt {

    Map<String, Route> routeMap;

    public MoovItImpl() {
        this.routeMap = new LinkedHashMap<>();
    }

    @Override
    public void addRoute(Route route) {
        Route current = this.routeMap.get(route.getId());
        if (current != null) {
            throw new IllegalArgumentException();
        }
        this.routeMap.put(route.getId(), route);
    }

    @Override
    public void removeRoute(String routeId) {
        Route current = this.routeMap.get(routeId);
        if (current == null) {
            throw new IllegalArgumentException();
        }
        this.routeMap.remove(routeId);
    }

    @Override
    public boolean contains(Route route) {
        return this.routeMap.containsKey(route.getId());
    }

    @Override
    public int size() {
        return this.routeMap.size();
    }

    @Override
    public Route getRoute(String routeId) {
        Route current = this.routeMap.get(routeId);
        if (current == null) {
            throw new IllegalArgumentException();
        }
        return current;
    }

    @Override
    public void chooseRoute(String routeId) {
        Route current = this.routeMap.get(routeId);
        if (current == null) {
            throw new IllegalArgumentException();
        }
        current.setPopularity(current.getPopularity() + 1);
    }

    @Override
    public Iterable<Route> searchRoutes(String startPoint, String endPoint) {
        List<Route> favouriteRoutes = this.routeMap.values().stream()
                .filter(r -> {
                    boolean isFavourite = r.getIsFavorite();
                    return isFavourite && routeIsValid(startPoint, endPoint, r);
                })
                .sorted(Comparator.comparing(Route::getPopularity))
                .collect(Collectors.toList());

        for (Route route : favouriteRoutes) {
            route.setLocationPoints(removeStops(route.getLocationPoints(), startPoint, endPoint));
        }

        favouriteRoutes = favouriteRoutes.stream()
                .sorted(Comparator.comparingInt(a -> a.getLocationPoints().size()))
                .collect(Collectors.toList());

        List<Route> nonFavouriteRoutes = this.routeMap.values().stream()
                .filter(r -> routeIsValid(startPoint, endPoint, r))
                .sorted(Comparator.comparingInt(a -> a.getLocationPoints().size()))
                .collect(Collectors.toList());

        for (Route route : nonFavouriteRoutes) {
            route.setLocationPoints(removeStops(route.getLocationPoints(), startPoint, endPoint));
        }

        nonFavouriteRoutes = nonFavouriteRoutes.stream()
                .sorted(Comparator.comparingInt(a -> a.getLocationPoints().size()))
                .collect(Collectors.toList());

        favouriteRoutes.addAll(nonFavouriteRoutes);
        return favouriteRoutes;
    }

    private List<String> removeStops(List<String> locationPoints, String startPoint, String endPoint) {
        List<String> newStops = new ArrayList<>();
        int startIndex = locationPoints.indexOf(startPoint);
        int endIndex = locationPoints.indexOf(endPoint);
        for (int i = startIndex; i <= endIndex; i++) {
            newStops.add(locationPoints.get(i));
        }
        return newStops;
    }

    @Override
    public Iterable<Route> getFavoriteRoutes(String destinationPoint) {
        return this.routeMap.values().stream()
                .filter(f -> f.getIsFavorite() &&
                        !f.getLocationPoints().get(0).equals(destinationPoint))
                .collect(Collectors.toList());
    }

    @Override
    public Iterable<Route> getTop5RoutesByPopularityThenByDistanceThenByCountOfLocationPoints() {
        return null;
    }

    private boolean routeIsValid(String startPoint, String endPoint, Route r) {
        List<String> location = r.getLocationPoints();
        int start = -1;
        int end = -1;
        for (int i = 0; i < location.size(); i++) {
            if (location.get(i).equals(startPoint)) {
                start = i;
            } else if (location.get(i).equals(endPoint)) {
                end = i;
            }
        }
        return start != -1 && end != -1 && start < end;
    }


}
