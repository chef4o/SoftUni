package core;

import models.Message;

import java.util.*;
import java.util.stream.Collectors;
import static java.util.stream.Collectors.toMap;

import static java.util.Comparator.comparingInt;

public class DiscordImpl implements Discord {

    public Map<String, Message> messages;
    public Map<String, List<Message>> messagesByChannel;

    public DiscordImpl() {
        this.messages = new LinkedHashMap<>();
        this.messagesByChannel = new LinkedHashMap<>();
    }

    @Override
    public void sendMessage(Message message) {
        this.messages.put(message.getId(), message);

        this.messagesByChannel.putIfAbsent(message.getChannel(), new ArrayList<>());
        this.messagesByChannel.get(message.getChannel()).add(message);
    }

    @Override
    public boolean contains(Message message) {
        return this.messages.containsKey(message.getId());
    }

    @Override
    public int size() {
        return this.messages.size();
    }

    @Override
    public Message getMessage(String messageId) {
        getIfPresent(messageId);
        return this.messages.get(messageId);
    }

    @Override
    public void deleteMessage(String messageId) {
        getIfPresent(messageId);
        this.messages.remove(messageId);
    }

    @Override
    public void reactToMessage(String messageId, String reaction) {
        getIfPresent(messageId);
        Message presentMessage = this.messages.get(messageId);
        presentMessage.getReactions().add(reaction);
    }

    @Override
    public Iterable<Message> getChannelMessages(String channel) {
        List<Message> allMessages = this.messagesByChannel.get(channel);
        if (allMessages.isEmpty()) {
            throw new IllegalArgumentException();
        }
        return allMessages;
    }

    @Override
    public Iterable<Message> getMessagesByReactions(List<String> reactions) {

        List<Message> allMsg = new ArrayList<>();
        Map<String, List<Message>> msgs = new HashMap<>();

        for (Message message : this.messages.values()) {
            List<String> react = message.getReactions();
            for (String r : react) {
                if (reactions.contains(r)) {
                    msgs.putIfAbsent(r, new ArrayList<>());
                    Message msg = message;
                    List<String> msgReacts = msg.getReactions();
                    for (int i = 0; i < msgReacts.size(); i++) {
                        if (!reactions.contains(msgReacts.get(i))) {
                            msgReacts.remove(i);
                            i--;
                        }
                    }
                    msgs.get(r).add(message);
                }
            }
        }
        msgs = sortMap(msgs);
        for (List<Message> list : msgs.values()) {
            for (Message message : list) {
                if (!allMsg.contains(message)) {
                    allMsg.add(message);
                }
            }
        }

        return allMsg.stream()
                .sorted((a,b) -> b.getReactions().size() - a.getReactions().size())
                .collect(Collectors.toList());
    }

    @Override
    public Iterable<Message> getMessageInTimeRange(Integer lowerBound, Integer upperBound) {
        return null;
    }

    @Override
    public Iterable<Message> getTop3MostReactedMessages() {
        return null;
    }

    @Override
    public Iterable<Message> getAllMessagesOrderedByCountOfReactionsThenByTimestampThenByLengthOfContent() {
        return null;
    }

    public void getIfPresent(String messageId) {
        Message present = this.messages.get(messageId);
        if (present == null) {
            throw new IllegalArgumentException("Message not present");
        }
    }

    public static <K,V extends Collection> Map<K,V> sortMap(Map<K,V> map){
        return map.entrySet().stream()
                .sorted((e1, e2) -> Integer.compare(e2.getValue().size(), e1.getValue().size()))
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1, LinkedHashMap::new));
    }
}
